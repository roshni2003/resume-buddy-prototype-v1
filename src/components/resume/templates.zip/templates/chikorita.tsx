import { EnvelopeIcon, GlobeIcon, MapPinIcon, PhoneIcon } from "@phosphor-icons/react";
import { cn } from "@/utils/style";
import { Section } from "../shared/get-section-component";
import { InlineEditableText } from "../shared/inline-editable-text";
import { PageIcon } from "../shared/page-icon";
import { PageLink } from "../shared/page-link";
import { PagePicture } from "../shared/page-picture";
import { useResumeStore } from "../store/resume";
import type { TemplateProps } from "./types";

const sectionClassName = cn(
	// Section Heading
	"[&>h6]:border-(--page-primary-color) [&>h6]:border-b",

	// Section Heading in Sidebar Layout
	"group-data-[layout=sidebar]:[&>h6]:text-(--page-background-color)",
	"group-data-[layout=sidebar]:[&>h6]:border-(--page-background-color)",

	// Icon Colors in Sidebar Layout
	"group-data-[layout=sidebar]:[&_.section-item_i]:text-(--page-background-color)!",

	// Level Display in Sidebar Layout
	"group-data-[layout=sidebar]:[&_.section-item-level_div]:border-(--page-background-color)",
	"group-data-[layout=sidebar]:[&_.section-item-level_div[data-active=true]]:bg-(--page-background-color)",
	"group-data-[layout=sidebar]:[&_.section-item-level_i[data-active=true]]:text-(--page-background-color)!",
	"group-data-[layout=sidebar]:[&_.section-item-level_i[data-active=false]]:opacity-40",

	// Section Item Header in Sidebar Layout
	"group-data-[layout=sidebar]:[&_.section-item-header>div]:flex-col",
	"group-data-[layout=sidebar]:[&_.section-item-header>div]:items-start",
);

/**
 * Template: Chikorita
 */
export function ChikoritaTemplate({ pageIndex, pageLayout }: TemplateProps) {
	const isFirstPage = pageIndex === 0;
	const { main, sidebar, fullWidth } = pageLayout;

	return (
		<div className="template-chikorita page-content">
			{/* Sidebar Background */}
			{!fullWidth && (
				<div className="page-sidebar-background pointer-events-none absolute inset-y-0 z-0 w-(--page-sidebar-width) shrink-0 bg-(--page-primary-color) ltr:end-0 rtl:start-0" />
			)}

			<div className="flex">
				<main
					data-layout="main"
					className="group page-main z-10 flex-1 space-y-4 px-(--page-margin-x) pt-(--page-margin-y)"
				>
					{isFirstPage && <Header />}
					{main.map((section) => (
						<Section key={section} type={section} id={section} sectionClassName={sectionClassName} />
					))}
				</main>

				{!fullWidth && (
					<aside
						data-layout="sidebar"
						className="group page-sidebar z-10 w-(--page-sidebar-width) shrink-0 space-y-4 overflow-x-hidden px-(--page-margin-x) pt-(--page-margin-y) text-(--page-background-color)"
					>
						{sidebar.map((section) => (
							<Section key={section} type={section} id={section} sectionClassName={sectionClassName} />
						))}
					</aside>
				)}
			</div>
		</div>
	);
}

function Header() {
	const basics = useResumeStore((state) => state.resume.data.basics);
	const updateResumeData = useResumeStore((state) => state.updateResumeData);

	const handleEmailChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.email = value;
		});
	};

	const handlePhoneChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.phone = value;
		});
	};

	const handleLocationChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.location = value;
		});
	};

	const handleNameChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.name = value;
		});
	};

	const handleHeadlineChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.headline = value;
		});
	};

	return (
		<div data-section-id="header" className="page-header relative flex">
			<div className="flex flex-1 items-start">
				<PagePicture />

				<div className="page-basics space-y-2 ps-4">
					<div>
						<h2 className="basics-name">
							<InlineEditableText value={basics.name} placeholder="Your Name" onChange={handleNameChange} />
						</h2>
						<p className="basics-headline">
							<InlineEditableText
								value={basics.headline}
								placeholder="Your Professional Title"
								onChange={handleHeadlineChange}
							/>
						</p>
					</div>

					<div className="basics-items flex flex-wrap gap-x-2 gap-y-0.5 *:flex *:items-center *:gap-x-1.5">
						<div className="basics-item-email break-anywhere min-w-0">
							<EnvelopeIcon />
							<InlineEditableText
								as="a"
								href={basics.email ? `mailto:${basics.email}` : undefined}
								value={basics.email}
								placeholder="email@domain.com"
								onChange={handleEmailChange}
							/>
						</div>

						<div className="basics-item-phone">
							<PhoneIcon />
							<InlineEditableText
								as="a"
								href={basics.phone ? `tel:${basics.phone}` : undefined}
								value={basics.phone}
								placeholder="+91 98765 43210"
								onChange={handlePhoneChange}
							/>
						</div>

						<div className="basics-item-location">
							<MapPinIcon />
							<InlineEditableText value={basics.location} placeholder="City, Country" onChange={handleLocationChange} />
						</div>

						{basics.website.url && (
							<div className="basics-item-website">
								<GlobeIcon />
								<PageLink {...basics.website} />
							</div>
						)}

						{basics.customFields.map((field) => (
							<div key={field.id} className="basics-item-custom">
								<PageIcon icon={field.icon} />
								{field.link ? <PageLink url={field.link} label={field.text} /> : <span>{field.text}</span>}
							</div>
						))}
					</div>
				</div>
			</div>
		</div>
	);
}
