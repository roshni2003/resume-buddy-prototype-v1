import { EnvelopeIcon, GlobeIcon, MapPinIcon, PhoneIcon } from "@phosphor-icons/react";
import { cn } from "@/utils/style";
import { Section } from "../shared/get-section-component";
import { InlineEditableText } from "../shared/inline-editable-text";
import { PageIcon } from "../shared/page-icon";
import { PageLink } from "../shared/page-link";
import { PagePicture } from "../shared/page-picture";
import { useResumeStore } from "../store/resume";
import type { TemplateProps } from "./types";

const sectionClassName = cn(
	// Section Heading
	"[&>h6]:border-(--page-primary-color) [&>h6]:border-b",

	// Section Item Header in Sidebar Layout
	"group-data-[layout=sidebar]:[&_.section-item-header>div]:flex-col",
	"group-data-[layout=sidebar]:[&_.section-item-header>div]:items-start",
);

/**
 * Template: Pikachu
 */
export function PikachuTemplate({ pageIndex, pageLayout }: TemplateProps) {
	const isFirstPage = pageIndex === 0;
	const { main, sidebar, fullWidth } = pageLayout;

	return (
		<div className="template-pikachu page-content space-y-(--page-gap-y) px-(--page-margin-x) pt-(--page-margin-y)">
			<div className="flex gap-x-(--page-margin-x)">
				{!fullWidth && (
					<aside
						data-layout="sidebar"
						className="group page-sidebar flex w-(--page-sidebar-width) shrink-0 flex-col space-y-(--page-gap-y)"
					>
						{isFirstPage && (
							<div className="flex max-w-(--page-sidebar-width) items-center justify-start">
								<PagePicture />
							</div>
						)}

						{!fullWidth && (
							<div className="shrink-0 space-y-(--page-gap-y) overflow-x-hidden">
								{sidebar.map((section) => (
									<Section key={section} type={section} id={section} sectionClassName={sectionClassName} />
								))}
							</div>
						)}
					</aside>
				)}

				<main data-layout="main" className="group page-main flex-1 space-y-(--page-gap-y)">
					{isFirstPage && (
						<div className="flex items-center gap-x-6">
							{fullWidth && <PagePicture />}
							<Header />
						</div>
					)}

					<div className="space-y-(--page-gap-y)">
						{main.map((section) => (
							<Section key={section} type={section} id={section} sectionClassName={sectionClassName} />
						))}
					</div>
				</main>
			</div>
		</div>
	);
}

function Header() {
	const basics = useResumeStore((state) => state.resume.data.basics);
	const updateResumeData = useResumeStore((state) => state.updateResumeData);

	const handleEmailChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.email = value;
		});
	};

	const handlePhoneChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.phone = value;
		});
	};

	const handleLocationChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.location = value;
		});
	};

	const handleNameChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.name = value;
		});
	};

	const handleHeadlineChange = (value: string) => {
		updateResumeData((draft) => {
			draft.basics.headline = value;
		});
	};

	return (
		<div
			data-section-id="header"
			className="page-header w-full space-y-(--page-gap-y) rounded-(--picture-border-radius) bg-(--page-primary-color) px-(--page-margin-x) py-(--page-margin-y) text-(--page-background-color)"
		>
			<div className="border-(--page-background-color)/50 border-b pb-2">
				<h2 className="basics-name">
					<InlineEditableText value={basics.name} placeholder="Your Name" onChange={handleNameChange} />
				</h2>
				<p className="basics-headline">
					<InlineEditableText
						value={basics.headline}
						placeholder="Your Professional Title"
						onChange={handleHeadlineChange}
					/>
				</p>
			</div>

			<div
				className="basics-items flex flex-wrap gap-x-3 gap-y-0.5 *:flex *:items-center *:gap-x-1.5"
				style={{ "--page-primary-color": "var(--page-background-color)" } as React.CSSProperties}
			>
				<div className="basics-item-email">
					<EnvelopeIcon />
					<InlineEditableText
						as="a"
						href={basics.email ? `mailto:${basics.email}` : undefined}
						value={basics.email}
						placeholder="email@domain.com"
						onChange={handleEmailChange}
					/>
				</div>

				<div className="basics-item-phone">
					<PhoneIcon />
					<InlineEditableText
						as="a"
						href={basics.phone ? `tel:${basics.phone}` : undefined}
						value={basics.phone}
						placeholder="+91 98765 43210"
						onChange={handlePhoneChange}
					/>
				</div>

				<div className="basics-item-location">
					<MapPinIcon />
					<InlineEditableText value={basics.location} placeholder="City, Country" onChange={handleLocationChange} />
				</div>

				{basics.website.url && (
					<div className="basics-item-website">
						<GlobeIcon />
						<PageLink {...basics.website} />
					</div>
				)}

				{basics.customFields.map((field) => (
					<div key={field.id} className="basics-item-custom">
						<PageIcon icon={field.icon} />
						{field.link ? <PageLink url={field.link} label={field.text} /> : <span>{field.text}</span>}
					</div>
				))}
			</div>
		</div>
	);
}
